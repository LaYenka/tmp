"""Main Ordered Set module """

from oset.pyoset import oset
